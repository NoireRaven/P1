#include<iostream>
using namespace std;
int main () {
    int count;
    int i;
    int numbers[i];
    cout<<"enter the count of your numbers: ";
    cin>>count;
    for (i=0; i<count; i++) {
        cout<<"enter number: "<<i+1;
         cin>>numbers[i];
    }
    float max=numbers[0];
    float min=numbers[0];
    float sum=0;
    for (int i=0; i<count; i++) {
        if (numbers[i]>max) {
             max=numbers[i];
        }
        if (numbers[i]<min) {
            min=numbers[i];
        }
        sum+=numbers[i];
    }
    float avg=sum/count;
    cout<<"max: "<<max<<endl;
    cout<<"min: "<<min<<endl;
    cout<<"average: "<<avg<<endl;
}